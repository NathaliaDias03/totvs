Projeto  - Totvs

- npm install -g @angular/cli 
- npm install bootstrap 

Para testes 

- ng test 