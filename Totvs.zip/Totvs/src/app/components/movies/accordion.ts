import { Component } from '@angular/core';
 
@Component({
  selector: 'demo-accordion-basic',
  templateUrl: './movies.component.html'
})
export class DemoAccordionBasicComponent {}