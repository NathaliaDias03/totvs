import { Component,TemplateRef } from '@angular/core';
import { MovieService } from '../../services/movie.service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';


@Component({
  selector: 'app-movies',
  templateUrl: 'movies.component.html',
  styleUrls: ['movies.component.scss'],
})
export class MoviesComponent  {
   
  modalRef: BsModalRef;
  searchStr: string;
  searchRes: Array<Object>;

  constructor(private _movieService: MovieService,
    private modalService: BsModalService) {

  }

  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }

  searchMovies() {
    this._movieService.searchMovies(this.searchStr).subscribe( res => {
      this.searchRes = res.results;
    });
  } 
  

}
//