import { Component, TemplateRef } from '@angular/core';
import { MovieService } from './services/movie.service';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [MovieService]
})

@Component({
  selector: 'ngbd-modal-basic',
  templateUrl: './components/movies/movies.component.html'
})
export class AppComponent {
  title = 'app';
  public modalRef: BsModalRef; // {1}
  constructor(private modalService: BsModalService) {} // {2}

  public openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template); // {3}
  }
}
